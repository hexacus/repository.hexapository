# plugin.program.HexWiz
Fork of "OpenWizard" from a4k-openproject

OpenWizard was created to help the Kodi community out and help get rid of the broken personal wizards that are floating around.
For more information on how to edit/customize this wizard for your own usage, please read [the wiki](https://github.com/drinfernoo/plugin.program.openwizard/wiki).


<img align="left" src="icon.png" width="256" hspace="48" title="The Hexacus Repository">

<p align="right">
  <ul>
    OpenWizard was created to help 
	the Kodi community out and help 
	get rid of the broken personal 
	wizards that are floating around.
    For more information on how to 
	edit/customize this wizard for 
	your own usage, please read [the wiki]
	(https://github.com/drinfernoo/plugin.program.openwizard/wiki). 
  </ul>
</p>






## Enjoy!